package DefiningClasses;

public class Car {
    private String brand;
    private String model;
    private int power;

    public Car(String carBrand, String carModel, int carPower) {
        this.brand = carBrand;
        this.model = carModel;
        this.power = carPower;
    }


    public String getBrand() {
        return this.brand;
    }

    public String getModel() {
        return this.model;
    }

    public int getPower() {
        return this.power;
    }

    public void setBrand(String brand) {
        this.brand = brand;
    }

    public void setModel(String model) {
        this.model = model;
    }
    public void setPower (int power){
        this.power = power;
    }
    public String toString () {
        return String.format("The car is: %s %s - %d HP."
                , this.brand, this.model, this.power);
    }



//    //public void setPower(int power) {
//        this.power = power;
//    }
}
