package DefiningClasses;

import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        // Car car = new Car();

//        car.brand = "Chevrolet";
//        car.model = "Impala";
//        car.power = 390;
//        car.setBrand("Chevrolet");
//        car.setModel("Impala");
//        car.setPower(390);

//        System.out.printf("The car is %s %s - %d HP", car.brand, car.model, car.power);
//        System.out.printf("The car is %s %s - %d HP", car.getBrand(), car.getModel(), car.getPower());
//        System.out.println(car.toString());


        //////////////////////////////////////////
        int n = Integer.parseInt(scanner.nextLine());
        List<Car> listCar = new ArrayList<>();

        for (int i = 0; i < n; i++) {
            String[] input = scanner.nextLine().split(" ");
            String carBrand = input[0];
            String carModel = input[1];
            int carPower = Integer.parseInt(input[2]);
            Car car = new Car(carBrand, carModel, carPower);
            listCar.add(car);
        }
        for (Car car : listCar) {
            System.out.println(car);
        }
    }
}
