package ExercisesDefiningClasses;

import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        List<Engine> listEngine = new ArrayList<>();

        int n = Integer.parseInt(scanner.nextLine());
        for (int i = 0; i < n; i++) {
            String[] data = scanner.nextLine().split(" ");
            String modelEngine= data[0];
            String powerEngine = data[1];
            String displacement;
            String efficiency;
            if (data.length == 2) {
                Engine engine = new Engine(modelEngine, powerEngine);
                listEngine.add(engine);
            } else if (data.length == 3) {
                displacement = data[2];
                Engine engine = new Engine(modelEngine, powerEngine, displacement);
                listEngine.add(engine);
            } else if (data.length == 4) {
                displacement = data[2];
                efficiency = data[3];
                Engine engine = new Engine(modelEngine, powerEngine, displacement, efficiency);
                listEngine.add(engine);
            }
        }
        n = Integer.parseInt(scanner.nextLine());
        List<Car> listCar = new ArrayList<>();
        for (int i = 0; i < n; i++) {
            String[] data = scanner.nextLine().split(" ");
            String modelCar = data[0];
            String powerCar = data[1];
            String weightCar;
            String colorCar;
            if (data.length == 2) {
                Car car = new Car(modelCar, powerCar);
                listCar.add(car);
//                if (listEngine.contains(data[2])){
//                    Car car1 = new Car(modelCar, powerCar);
//                    int index = listEngine.indexOf(data[2]);
//                    listEngine.add(index, car1);
//                }
            } else if (data.length == 3) {
                weightCar = data[2];
                Car car = new Car(modelCar, powerCar, weightCar);
                listCar.add(car);
            } else if (data.length == 4) {
                weightCar = data[2];
                colorCar = data[3];
                Car car = new Car(modelCar, powerCar, weightCar, colorCar);
                listCar.add(car);
            }
        }
        for (Car car : listCar) {
            for (Engine engine : listEngine) {
                if (car.getEngineCar().equals(engine.getModelEngine())){
                    System.out.println(car.getModelCar() + ":");
                    System.out.println(engine.getModelEngine()+ ":");
                    System.out.printf("Power: %s%n",engine.getPower());
                    System.out.printf("Displacement: %s%n", engine.getDisplacement());
                    System.out.printf("Efficiency: %s%n", engine.getEfficiency());
                    System.out.printf("Weight: %s%n", car.getWeightCar());
                    System.out.printf("Color: %s%n", car.getColorCar());


                }
            }
        }

        System.out.println();

    }
}
