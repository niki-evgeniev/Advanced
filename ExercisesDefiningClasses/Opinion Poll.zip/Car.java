package ExercisesDefiningClasses;

public class Car {
    private String name;
    private int age;

    public Car(String name, int age) {
        this.name = name;
        this.age = age;
    }

    public Car() {

    }

    public void add(String name, int age) {
        this.name = name;
        this.age = age;

    }
    public int getAge(){
        return age;
    }

    @Override
    public String toString() {
        return String.format("%s - %d", this.getName(), this.getAge());
    }

    public String getName(){
        return name;
    }


}
