package ExercisesDefiningClasses;

import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        int n = Integer.parseInt(scanner.nextLine());
        List<Car> listCars = new ArrayList<>();
        for (int i = 0; i < n; i++) {
            String[] data = scanner.nextLine().split(" ");
            String carModel = data[0];
            int speed = Integer.parseInt(data[1]);
            int power = Integer.parseInt(data[2]);
            int cargoWeight = Integer.parseInt(data[3]);
            String cargoType = data[4];
            double tire1Pressure = Double.parseDouble(data[5]);
            int tireAge1 = Integer.parseInt(data[6]);
            double tire2Pressure = Double.parseDouble(data[7]);
            int tireAge2 = Integer.parseInt(data[8]);
            double tire3Pressure = Double.parseDouble(data[9]);
            int tireAge3 = Integer.parseInt(data[10]);
            double tire4Pressure = Double.parseDouble(data[11]);
            int tireAge4 = Integer.parseInt(data[12]);

            Car car = new Car(carModel, speed, power, cargoWeight, cargoType,
                    tire1Pressure,tireAge1, tire2Pressure, tireAge2,
                    tire3Pressure, tireAge3, tire4Pressure, tireAge4);
            listCars.add(car);
        }
        String command = scanner.nextLine();
        if (command.equals("fragile")){
            for (Car car : listCars) {
                if (car.getTire1()< 1 || car.getTire2() < 1 || car.getTire3() < 1 || car.getTire4() < 1){
                    if (car.getCargoType().equals("fragile")){
                        System.out.println(car);
                    }
                }
            }
        }else if (command.equals("flamable")){
            for (Car car : listCars) {
                if (car.getCargoType().equals("flamable") && car.getEnginePower() > 250){
                    System.out.println(car);
                }
            }
        }

    }
}
